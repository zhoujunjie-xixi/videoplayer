from BC.GUI.FeatureExtractionForm2 import FeatureExtractionForm
from BC.GUI.PrepareForm import PrepareConnection
from BC.GUI.ProcessForm import ProcessConnection
from BC.GUI.VisualizationForm import VisualizationConnection
