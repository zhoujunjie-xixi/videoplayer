# Video Player with Signal for Test Observations 

This basic project is a kind of video player which can be useful if you have any measurement during any laboratory tests. Within that software, you can load your signals and videos together and you can play the video and trace the obtained signal simultaneously. Here is the acreenshot of gui during running. This repository is also good sample of how to create GUI and play video.

To run it please sun the main script in src folder as follows;

```
$ python video_player_signal.py
```


![Sample image](data/videoaudio.jpg?raw=true "Title")




